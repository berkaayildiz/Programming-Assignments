package tr.edu.iyte.ceng112.traversaliterator;

import java.util.Iterator;


public class PostorderIterator<T> implements Iterator<T> {

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public T next() {
		// TODO Auto-generated method stub
		return null;
	}

}
